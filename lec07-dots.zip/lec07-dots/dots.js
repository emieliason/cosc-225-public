const ns = "http://www.w3.org/2000/svg";

const box = document.querySelector("#dot-box");
box.addEventListener("click", drawDot);

function drawDot(e) {
    console.log("you drew a dot!");

    /* complete this */

}
